import operaciones 

print(operaciones.suma(4,4))
print(operaciones.resta(12,5))
print(operaciones.multiplicacion(9,8))
print(operaciones.divicion(20,4)) 